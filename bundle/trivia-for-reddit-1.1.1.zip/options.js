(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
'use strict';

var token = '%[a-f0-9]{2}';
var singleMatcher = new RegExp(token, 'gi');
var multiMatcher = new RegExp('(' + token + ')+', 'gi');

function decodeComponents(components, split) {
  try {
    // Try to decode the entire string first
    return decodeURIComponent(components.join(''));
  } catch (err) {// Do nothing
  }

  if (components.length === 1) {
    return components;
  }

  split = split || 1; // Split the array in 2 parts

  var left = components.slice(0, split);
  var right = components.slice(split);
  return Array.prototype.concat.call([], decodeComponents(left), decodeComponents(right));
}

function decode(input) {
  try {
    return decodeURIComponent(input);
  } catch (err) {
    var tokens = input.match(singleMatcher);

    for (var i = 1; i < tokens.length; i++) {
      input = decodeComponents(tokens, i).join('');
      tokens = input.match(singleMatcher);
    }

    return input;
  }
}

function customDecodeURIComponent(input) {
  // Keep track of all the replacements and prefill the map with the `BOM`
  var replaceMap = {
    '%FE%FF': '\uFFFD\uFFFD',
    '%FF%FE': '\uFFFD\uFFFD'
  };
  var match = multiMatcher.exec(input);

  while (match) {
    try {
      // Decode as big chunks as possible
      replaceMap[match[0]] = decodeURIComponent(match[0]);
    } catch (err) {
      var result = decode(match[0]);

      if (result !== match[0]) {
        replaceMap[match[0]] = result;
      }
    }

    match = multiMatcher.exec(input);
  } // Add `%C2` at the end of the map to make sure it does not replace the combinator before everything else


  replaceMap['%C2'] = '\uFFFD';
  var entries = Object.keys(replaceMap);

  for (var i = 0; i < entries.length; i++) {
    // Replace all decoded components
    var key = entries[i];
    input = input.replace(new RegExp(key, 'g'), replaceMap[key]);
  }

  return input;
}

module.exports = function (encodedURI) {
  if (typeof encodedURI !== 'string') {
    throw new TypeError('Expected `encodedURI` to be of type `string`, got `' + typeof encodedURI + '`');
  }

  try {
    encodedURI = encodedURI.replace(/\+/g, ' '); // Try the built in decoder first

    return decodeURIComponent(encodedURI);
  } catch (err) {
    // Fallback to a more advanced decoder
    return customDecodeURIComponent(encodedURI);
  }
};

},{}],2:[function(require,module,exports){
(function (global, factory) {
  typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports) : typeof define === 'function' && define.amd ? define(['exports'], factory) : factory(global.preact = {});
})(this, function (exports) {
  'use strict';

  var VNode = function VNode() {};

  var options = {};
  var stack = [];
  var EMPTY_CHILDREN = [];

  function h(nodeName, attributes) {
    var children = EMPTY_CHILDREN,
        lastSimple = void 0,
        child = void 0,
        simple = void 0,
        i = void 0;

    for (i = arguments.length; i-- > 2;) {
      stack.push(arguments[i]);
    }

    if (attributes && attributes.children != null) {
      if (!stack.length) stack.push(attributes.children);
      delete attributes.children;
    }

    while (stack.length) {
      if ((child = stack.pop()) && child.pop !== undefined) {
        for (i = child.length; i--;) {
          stack.push(child[i]);
        }
      } else {
        if (typeof child === 'boolean') child = null;

        if (simple = typeof nodeName !== 'function') {
          if (child == null) child = '';else if (typeof child === 'number') child = String(child);else if (typeof child !== 'string') simple = false;
        }

        if (simple && lastSimple) {
          children[children.length - 1] += child;
        } else if (children === EMPTY_CHILDREN) {
          children = [child];
        } else {
          children.push(child);
        }

        lastSimple = simple;
      }
    }

    var p = new VNode();
    p.nodeName = nodeName;
    p.children = children;
    p.attributes = attributes == null ? undefined : attributes;
    p.key = attributes == null ? undefined : attributes.key;
    if (options.vnode !== undefined) options.vnode(p);
    return p;
  }

  function extend(obj, props) {
    for (var i in props) {
      obj[i] = props[i];
    }

    return obj;
  }

  function applyRef(ref, value) {
    if (ref) {
      if (typeof ref == 'function') ref(value);else ref.current = value;
    }
  }

  var defer = typeof Promise == 'function' ? Promise.resolve().then.bind(Promise.resolve()) : setTimeout;

  function cloneElement(vnode, props) {
    return h(vnode.nodeName, extend(extend({}, vnode.attributes), props), arguments.length > 2 ? [].slice.call(arguments, 2) : vnode.children);
  }

  var NO_RENDER = 0;
  var SYNC_RENDER = 1;
  var FORCE_RENDER = 2;
  var ASYNC_RENDER = 3;
  var ATTR_KEY = '__preactattr_';
  var IS_NON_DIMENSIONAL = /acit|ex(?:s|g|n|p|$)|rph|ows|mnc|ntw|ine[ch]|zoo|^ord/i;
  var items = [];

  function enqueueRender(component) {
    if (!component._dirty && (component._dirty = true) && items.push(component) == 1) {
      (options.debounceRendering || defer)(rerender);
    }
  }

  function rerender() {
    var p = void 0;

    while (p = items.pop()) {
      if (p._dirty) renderComponent(p);
    }
  }

  function isSameNodeType(node, vnode, hydrating) {
    if (typeof vnode === 'string' || typeof vnode === 'number') {
      return node.splitText !== undefined;
    }

    if (typeof vnode.nodeName === 'string') {
      return !node._componentConstructor && isNamedNode(node, vnode.nodeName);
    }

    return hydrating || node._componentConstructor === vnode.nodeName;
  }

  function isNamedNode(node, nodeName) {
    return node.normalizedNodeName === nodeName || node.nodeName.toLowerCase() === nodeName.toLowerCase();
  }

  function getNodeProps(vnode) {
    var props = extend({}, vnode.attributes);
    props.children = vnode.children;
    var defaultProps = vnode.nodeName.defaultProps;

    if (defaultProps !== undefined) {
      for (var i in defaultProps) {
        if (props[i] === undefined) {
          props[i] = defaultProps[i];
        }
      }
    }

    return props;
  }

  function createNode(nodeName, isSvg) {
    var node = isSvg ? document.createElementNS('http://www.w3.org/2000/svg', nodeName) : document.createElement(nodeName);
    node.normalizedNodeName = nodeName;
    return node;
  }

  function removeNode(node) {
    var parentNode = node.parentNode;
    if (parentNode) parentNode.removeChild(node);
  }

  function setAccessor(node, name, old, value, isSvg) {
    if (name === 'className') name = 'class';

    if (name === 'key') {} else if (name === 'ref') {
      applyRef(old, null);
      applyRef(value, node);
    } else if (name === 'class' && !isSvg) {
      node.className = value || '';
    } else if (name === 'style') {
      if (!value || typeof value === 'string' || typeof old === 'string') {
        node.style.cssText = value || '';
      }

      if (value && typeof value === 'object') {
        if (typeof old !== 'string') {
          for (var i in old) {
            if (!(i in value)) node.style[i] = '';
          }
        }

        for (var _i in value) {
          node.style[_i] = typeof value[_i] === 'number' && IS_NON_DIMENSIONAL.test(_i) === false ? value[_i] + 'px' : value[_i];
        }
      }
    } else if (name === 'dangerouslySetInnerHTML') {
      if (value) node.innerHTML = value.__html || '';
    } else if (name[0] == 'o' && name[1] == 'n') {
      var useCapture = name !== (name = name.replace(/Capture$/, ''));
      name = name.toLowerCase().substring(2);

      if (value) {
        if (!old) node.addEventListener(name, eventProxy, useCapture);
      } else {
        node.removeEventListener(name, eventProxy, useCapture);
      }

      (node._listeners || (node._listeners = {}))[name] = value;
    } else if (name !== 'list' && name !== 'type' && !isSvg && name in node) {
      try {
        node[name] = value == null ? '' : value;
      } catch (e) {}

      if ((value == null || value === false) && name != 'spellcheck') node.removeAttribute(name);
    } else {
      var ns = isSvg && name !== (name = name.replace(/^xlink:?/, ''));

      if (value == null || value === false) {
        if (ns) node.removeAttributeNS('http://www.w3.org/1999/xlink', name.toLowerCase());else node.removeAttribute(name);
      } else if (typeof value !== 'function') {
        if (ns) node.setAttributeNS('http://www.w3.org/1999/xlink', name.toLowerCase(), value);else node.setAttribute(name, value);
      }
    }
  }

  function eventProxy(e) {
    return this._listeners[e.type](options.event && options.event(e) || e);
  }

  var mounts = [];
  var diffLevel = 0;
  var isSvgMode = false;
  var hydrating = false;

  function flushMounts() {
    var c = void 0;

    while (c = mounts.shift()) {
      if (options.afterMount) options.afterMount(c);
      if (c.componentDidMount) c.componentDidMount();
    }
  }

  function diff(dom, vnode, context, mountAll, parent, componentRoot) {
    if (!diffLevel++) {
      isSvgMode = parent != null && parent.ownerSVGElement !== undefined;
      hydrating = dom != null && !(ATTR_KEY in dom);
    }

    var ret = idiff(dom, vnode, context, mountAll, componentRoot);
    if (parent && ret.parentNode !== parent) parent.appendChild(ret);

    if (! --diffLevel) {
      hydrating = false;
      if (!componentRoot) flushMounts();
    }

    return ret;
  }

  function idiff(dom, vnode, context, mountAll, componentRoot) {
    var out = dom,
        prevSvgMode = isSvgMode;
    if (vnode == null || typeof vnode === 'boolean') vnode = '';

    if (typeof vnode === 'string' || typeof vnode === 'number') {
      if (dom && dom.splitText !== undefined && dom.parentNode && (!dom._component || componentRoot)) {
        if (dom.nodeValue != vnode) {
          dom.nodeValue = vnode;
        }
      } else {
        out = document.createTextNode(vnode);

        if (dom) {
          if (dom.parentNode) dom.parentNode.replaceChild(out, dom);
          recollectNodeTree(dom, true);
        }
      }

      out[ATTR_KEY] = true;
      return out;
    }

    var vnodeName = vnode.nodeName;

    if (typeof vnodeName === 'function') {
      return buildComponentFromVNode(dom, vnode, context, mountAll);
    }

    isSvgMode = vnodeName === 'svg' ? true : vnodeName === 'foreignObject' ? false : isSvgMode;
    vnodeName = String(vnodeName);

    if (!dom || !isNamedNode(dom, vnodeName)) {
      out = createNode(vnodeName, isSvgMode);

      if (dom) {
        while (dom.firstChild) {
          out.appendChild(dom.firstChild);
        }

        if (dom.parentNode) dom.parentNode.replaceChild(out, dom);
        recollectNodeTree(dom, true);
      }
    }

    var fc = out.firstChild,
        props = out[ATTR_KEY],
        vchildren = vnode.children;

    if (props == null) {
      props = out[ATTR_KEY] = {};

      for (var a = out.attributes, i = a.length; i--;) {
        props[a[i].name] = a[i].value;
      }
    }

    if (!hydrating && vchildren && vchildren.length === 1 && typeof vchildren[0] === 'string' && fc != null && fc.splitText !== undefined && fc.nextSibling == null) {
      if (fc.nodeValue != vchildren[0]) {
        fc.nodeValue = vchildren[0];
      }
    } else if (vchildren && vchildren.length || fc != null) {
      innerDiffNode(out, vchildren, context, mountAll, hydrating || props.dangerouslySetInnerHTML != null);
    }

    diffAttributes(out, vnode.attributes, props);
    isSvgMode = prevSvgMode;
    return out;
  }

  function innerDiffNode(dom, vchildren, context, mountAll, isHydrating) {
    var originalChildren = dom.childNodes,
        children = [],
        keyed = {},
        keyedLen = 0,
        min = 0,
        len = originalChildren.length,
        childrenLen = 0,
        vlen = vchildren ? vchildren.length : 0,
        j = void 0,
        c = void 0,
        f = void 0,
        vchild = void 0,
        child = void 0;

    if (len !== 0) {
      for (var i = 0; i < len; i++) {
        var _child = originalChildren[i],
            props = _child[ATTR_KEY],
            key = vlen && props ? _child._component ? _child._component.__key : props.key : null;

        if (key != null) {
          keyedLen++;
          keyed[key] = _child;
        } else if (props || (_child.splitText !== undefined ? isHydrating ? _child.nodeValue.trim() : true : isHydrating)) {
          children[childrenLen++] = _child;
        }
      }
    }

    if (vlen !== 0) {
      for (var _i = 0; _i < vlen; _i++) {
        vchild = vchildren[_i];
        child = null;
        var _key = vchild.key;

        if (_key != null) {
          if (keyedLen && keyed[_key] !== undefined) {
            child = keyed[_key];
            keyed[_key] = undefined;
            keyedLen--;
          }
        } else if (min < childrenLen) {
          for (j = min; j < childrenLen; j++) {
            if (children[j] !== undefined && isSameNodeType(c = children[j], vchild, isHydrating)) {
              child = c;
              children[j] = undefined;
              if (j === childrenLen - 1) childrenLen--;
              if (j === min) min++;
              break;
            }
          }
        }

        child = idiff(child, vchild, context, mountAll);
        f = originalChildren[_i];

        if (child && child !== dom && child !== f) {
          if (f == null) {
            dom.appendChild(child);
          } else if (child === f.nextSibling) {
            removeNode(f);
          } else {
            dom.insertBefore(child, f);
          }
        }
      }
    }

    if (keyedLen) {
      for (var _i2 in keyed) {
        if (keyed[_i2] !== undefined) recollectNodeTree(keyed[_i2], false);
      }
    }

    while (min <= childrenLen) {
      if ((child = children[childrenLen--]) !== undefined) recollectNodeTree(child, false);
    }
  }

  function recollectNodeTree(node, unmountOnly) {
    var component = node._component;

    if (component) {
      unmountComponent(component);
    } else {
      if (node[ATTR_KEY] != null) applyRef(node[ATTR_KEY].ref, null);

      if (unmountOnly === false || node[ATTR_KEY] == null) {
        removeNode(node);
      }

      removeChildren(node);
    }
  }

  function removeChildren(node) {
    node = node.lastChild;

    while (node) {
      var next = node.previousSibling;
      recollectNodeTree(node, true);
      node = next;
    }
  }

  function diffAttributes(dom, attrs, old) {
    var name = void 0;

    for (name in old) {
      if (!(attrs && attrs[name] != null) && old[name] != null) {
        setAccessor(dom, name, old[name], old[name] = undefined, isSvgMode);
      }
    }

    for (name in attrs) {
      if (name !== 'children' && name !== 'innerHTML' && (!(name in old) || attrs[name] !== (name === 'value' || name === 'checked' ? dom[name] : old[name]))) {
        setAccessor(dom, name, old[name], old[name] = attrs[name], isSvgMode);
      }
    }
  }

  var recyclerComponents = [];

  function createComponent(Ctor, props, context) {
    var inst = void 0,
        i = recyclerComponents.length;

    if (Ctor.prototype && Ctor.prototype.render) {
      inst = new Ctor(props, context);
      Component.call(inst, props, context);
    } else {
      inst = new Component(props, context);
      inst.constructor = Ctor;
      inst.render = doRender;
    }

    while (i--) {
      if (recyclerComponents[i].constructor === Ctor) {
        inst.nextBase = recyclerComponents[i].nextBase;
        recyclerComponents.splice(i, 1);
        return inst;
      }
    }

    return inst;
  }

  function doRender(props, state, context) {
    return this.constructor(props, context);
  }

  function setComponentProps(component, props, renderMode, context, mountAll) {
    if (component._disable) return;
    component._disable = true;
    component.__ref = props.ref;
    component.__key = props.key;
    delete props.ref;
    delete props.key;

    if (typeof component.constructor.getDerivedStateFromProps === 'undefined') {
      if (!component.base || mountAll) {
        if (component.componentWillMount) component.componentWillMount();
      } else if (component.componentWillReceiveProps) {
        component.componentWillReceiveProps(props, context);
      }
    }

    if (context && context !== component.context) {
      if (!component.prevContext) component.prevContext = component.context;
      component.context = context;
    }

    if (!component.prevProps) component.prevProps = component.props;
    component.props = props;
    component._disable = false;

    if (renderMode !== NO_RENDER) {
      if (renderMode === SYNC_RENDER || options.syncComponentUpdates !== false || !component.base) {
        renderComponent(component, SYNC_RENDER, mountAll);
      } else {
        enqueueRender(component);
      }
    }

    applyRef(component.__ref, component);
  }

  function renderComponent(component, renderMode, mountAll, isChild) {
    if (component._disable) return;
    var props = component.props,
        state = component.state,
        context = component.context,
        previousProps = component.prevProps || props,
        previousState = component.prevState || state,
        previousContext = component.prevContext || context,
        isUpdate = component.base,
        nextBase = component.nextBase,
        initialBase = isUpdate || nextBase,
        initialChildComponent = component._component,
        skip = false,
        snapshot = previousContext,
        rendered = void 0,
        inst = void 0,
        cbase = void 0;

    if (component.constructor.getDerivedStateFromProps) {
      state = extend(extend({}, state), component.constructor.getDerivedStateFromProps(props, state));
      component.state = state;
    }

    if (isUpdate) {
      component.props = previousProps;
      component.state = previousState;
      component.context = previousContext;

      if (renderMode !== FORCE_RENDER && component.shouldComponentUpdate && component.shouldComponentUpdate(props, state, context) === false) {
        skip = true;
      } else if (component.componentWillUpdate) {
        component.componentWillUpdate(props, state, context);
      }

      component.props = props;
      component.state = state;
      component.context = context;
    }

    component.prevProps = component.prevState = component.prevContext = component.nextBase = null;
    component._dirty = false;

    if (!skip) {
      rendered = component.render(props, state, context);

      if (component.getChildContext) {
        context = extend(extend({}, context), component.getChildContext());
      }

      if (isUpdate && component.getSnapshotBeforeUpdate) {
        snapshot = component.getSnapshotBeforeUpdate(previousProps, previousState);
      }

      var childComponent = rendered && rendered.nodeName,
          toUnmount = void 0,
          base = void 0;

      if (typeof childComponent === 'function') {
        var childProps = getNodeProps(rendered);
        inst = initialChildComponent;

        if (inst && inst.constructor === childComponent && childProps.key == inst.__key) {
          setComponentProps(inst, childProps, SYNC_RENDER, context, false);
        } else {
          toUnmount = inst;
          component._component = inst = createComponent(childComponent, childProps, context);
          inst.nextBase = inst.nextBase || nextBase;
          inst._parentComponent = component;
          setComponentProps(inst, childProps, NO_RENDER, context, false);
          renderComponent(inst, SYNC_RENDER, mountAll, true);
        }

        base = inst.base;
      } else {
        cbase = initialBase;
        toUnmount = initialChildComponent;

        if (toUnmount) {
          cbase = component._component = null;
        }

        if (initialBase || renderMode === SYNC_RENDER) {
          if (cbase) cbase._component = null;
          base = diff(cbase, rendered, context, mountAll || !isUpdate, initialBase && initialBase.parentNode, true);
        }
      }

      if (initialBase && base !== initialBase && inst !== initialChildComponent) {
        var baseParent = initialBase.parentNode;

        if (baseParent && base !== baseParent) {
          baseParent.replaceChild(base, initialBase);

          if (!toUnmount) {
            initialBase._component = null;
            recollectNodeTree(initialBase, false);
          }
        }
      }

      if (toUnmount) {
        unmountComponent(toUnmount);
      }

      component.base = base;

      if (base && !isChild) {
        var componentRef = component,
            t = component;

        while (t = t._parentComponent) {
          (componentRef = t).base = base;
        }

        base._component = componentRef;
        base._componentConstructor = componentRef.constructor;
      }
    }

    if (!isUpdate || mountAll) {
      mounts.push(component);
    } else if (!skip) {
      if (component.componentDidUpdate) {
        component.componentDidUpdate(previousProps, previousState, snapshot);
      }

      if (options.afterUpdate) options.afterUpdate(component);
    }

    while (component._renderCallbacks.length) {
      component._renderCallbacks.pop().call(component);
    }

    if (!diffLevel && !isChild) flushMounts();
  }

  function buildComponentFromVNode(dom, vnode, context, mountAll) {
    var c = dom && dom._component,
        originalComponent = c,
        oldDom = dom,
        isDirectOwner = c && dom._componentConstructor === vnode.nodeName,
        isOwner = isDirectOwner,
        props = getNodeProps(vnode);

    while (c && !isOwner && (c = c._parentComponent)) {
      isOwner = c.constructor === vnode.nodeName;
    }

    if (c && isOwner && (!mountAll || c._component)) {
      setComponentProps(c, props, ASYNC_RENDER, context, mountAll);
      dom = c.base;
    } else {
      if (originalComponent && !isDirectOwner) {
        unmountComponent(originalComponent);
        dom = oldDom = null;
      }

      c = createComponent(vnode.nodeName, props, context);

      if (dom && !c.nextBase) {
        c.nextBase = dom;
        oldDom = null;
      }

      setComponentProps(c, props, SYNC_RENDER, context, mountAll);
      dom = c.base;

      if (oldDom && dom !== oldDom) {
        oldDom._component = null;
        recollectNodeTree(oldDom, false);
      }
    }

    return dom;
  }

  function unmountComponent(component) {
    if (options.beforeUnmount) options.beforeUnmount(component);
    var base = component.base;
    component._disable = true;
    if (component.componentWillUnmount) component.componentWillUnmount();
    component.base = null;
    var inner = component._component;

    if (inner) {
      unmountComponent(inner);
    } else if (base) {
      if (base[ATTR_KEY] != null) applyRef(base[ATTR_KEY].ref, null);
      component.nextBase = base;
      removeNode(base);
      recyclerComponents.push(component);
      removeChildren(base);
    }

    applyRef(component.__ref, null);
  }

  function Component(props, context) {
    this._dirty = true;
    this.context = context;
    this.props = props;
    this.state = this.state || {};
    this._renderCallbacks = [];
  }

  extend(Component.prototype, {
    setState: function setState(state, callback) {
      if (!this.prevState) this.prevState = this.state;
      this.state = extend(extend({}, this.state), typeof state === 'function' ? state(this.state, this.props) : state);
      if (callback) this._renderCallbacks.push(callback);
      enqueueRender(this);
    },
    forceUpdate: function forceUpdate(callback) {
      if (callback) this._renderCallbacks.push(callback);
      renderComponent(this, FORCE_RENDER);
    },
    render: function render() {}
  });

  function render(vnode, parent, merge) {
    return diff(merge, vnode, {}, false, parent, false);
  }

  function createRef() {
    return {};
  }

  var preact = {
    h: h,
    createElement: h,
    cloneElement: cloneElement,
    createRef: createRef,
    Component: Component,
    render: render,
    rerender: rerender,
    options: options
  };
  exports.default = preact;
  exports.h = h;
  exports.createElement = h;
  exports.cloneElement = cloneElement;
  exports.createRef = createRef;
  exports.Component = Component;
  exports.render = render;
  exports.rerender = rerender;
  exports.options = options;
  Object.defineProperty(exports, '__esModule', {
    value: true
  });
});

},{}],3:[function(require,module,exports){
'use strict';

const strictUriEncode = require('strict-uri-encode');

const decodeComponent = require('decode-uri-component');

const splitOnFirst = require('split-on-first');

function encoderForArrayFormat(options) {
  switch (options.arrayFormat) {
    case 'index':
      return key => (result, value) => {
        const index = result.length;

        if (value === undefined) {
          return result;
        }

        if (value === null) {
          return [...result, [encode(key, options), '[', index, ']'].join('')];
        }

        return [...result, [encode(key, options), '[', encode(index, options), ']=', encode(value, options)].join('')];
      };

    case 'bracket':
      return key => (result, value) => {
        if (value === undefined) {
          return result;
        }

        if (value === null) {
          return [...result, [encode(key, options), '[]'].join('')];
        }

        return [...result, [encode(key, options), '[]=', encode(value, options)].join('')];
      };

    case 'comma':
      return key => (result, value, index) => {
        if (value === null || value === undefined || value.length === 0) {
          return result;
        }

        if (index === 0) {
          return [[encode(key, options), '=', encode(value, options)].join('')];
        }

        return [[result, encode(value, options)].join(',')];
      };

    default:
      return key => (result, value) => {
        if (value === undefined) {
          return result;
        }

        if (value === null) {
          return [...result, encode(key, options)];
        }

        return [...result, [encode(key, options), '=', encode(value, options)].join('')];
      };
  }
}

function parserForArrayFormat(options) {
  let result;

  switch (options.arrayFormat) {
    case 'index':
      return (key, value, accumulator) => {
        result = /\[(\d*)\]$/.exec(key);
        key = key.replace(/\[\d*\]$/, '');

        if (!result) {
          accumulator[key] = value;
          return;
        }

        if (accumulator[key] === undefined) {
          accumulator[key] = {};
        }

        accumulator[key][result[1]] = value;
      };

    case 'bracket':
      return (key, value, accumulator) => {
        result = /(\[\])$/.exec(key);
        key = key.replace(/\[\]$/, '');

        if (!result) {
          accumulator[key] = value;
          return;
        }

        if (accumulator[key] === undefined) {
          accumulator[key] = [value];
          return;
        }

        accumulator[key] = [].concat(accumulator[key], value);
      };

    case 'comma':
      return (key, value, accumulator) => {
        const isArray = typeof value === 'string' && value.split('').indexOf(',') > -1;
        const newValue = isArray ? value.split(',') : value;
        accumulator[key] = newValue;
      };

    default:
      return (key, value, accumulator) => {
        if (accumulator[key] === undefined) {
          accumulator[key] = value;
          return;
        }

        accumulator[key] = [].concat(accumulator[key], value);
      };
  }
}

function encode(value, options) {
  if (options.encode) {
    return options.strict ? strictUriEncode(value) : encodeURIComponent(value);
  }

  return value;
}

function decode(value, options) {
  if (options.decode) {
    return decodeComponent(value);
  }

  return value;
}

function keysSorter(input) {
  if (Array.isArray(input)) {
    return input.sort();
  }

  if (typeof input === 'object') {
    return keysSorter(Object.keys(input)).sort((a, b) => Number(a) - Number(b)).map(key => input[key]);
  }

  return input;
}

function removeHash(input) {
  const hashStart = input.indexOf('#');

  if (hashStart !== -1) {
    input = input.slice(0, hashStart);
  }

  return input;
}

function extract(input) {
  input = removeHash(input);
  const queryStart = input.indexOf('?');

  if (queryStart === -1) {
    return '';
  }

  return input.slice(queryStart + 1);
}

function parse(input, options) {
  options = Object.assign({
    decode: true,
    sort: true,
    arrayFormat: 'none',
    parseNumbers: false,
    parseBooleans: false
  }, options);
  const formatter = parserForArrayFormat(options); // Create an object with no prototype

  const ret = Object.create(null);

  if (typeof input !== 'string') {
    return ret;
  }

  input = input.trim().replace(/^[?#&]/, '');

  if (!input) {
    return ret;
  }

  for (const param of input.split('&')) {
    let [key, value] = splitOnFirst(param.replace(/\+/g, ' '), '='); // Missing `=` should be `null`:
    // http://w3.org/TR/2012/WD-url-20120524/#collect-url-parameters

    value = value === undefined ? null : decode(value, options);

    if (options.parseNumbers && !Number.isNaN(Number(value)) && typeof value === 'string' && value.trim() !== '') {
      value = Number(value);
    } else if (options.parseBooleans && value !== null && (value.toLowerCase() === 'true' || value.toLowerCase() === 'false')) {
      value = value.toLowerCase() === 'true';
    }

    formatter(decode(key, options), value, ret);
  }

  if (options.sort === false) {
    return ret;
  }

  return (options.sort === true ? Object.keys(ret).sort() : Object.keys(ret).sort(options.sort)).reduce((result, key) => {
    const value = ret[key];

    if (Boolean(value) && typeof value === 'object' && !Array.isArray(value)) {
      // Sort object keys, not values
      result[key] = keysSorter(value);
    } else {
      result[key] = value;
    }

    return result;
  }, Object.create(null));
}

exports.extract = extract;
exports.parse = parse;

exports.stringify = (object, options) => {
  if (!object) {
    return '';
  }

  options = Object.assign({
    encode: true,
    strict: true,
    arrayFormat: 'none'
  }, options);
  const formatter = encoderForArrayFormat(options);
  const keys = Object.keys(object);

  if (options.sort !== false) {
    keys.sort(options.sort);
  }

  return keys.map(key => {
    const value = object[key];

    if (value === undefined) {
      return '';
    }

    if (value === null) {
      return encode(key, options);
    }

    if (Array.isArray(value)) {
      return value.reduce(formatter(key), []).join('&');
    }

    return encode(key, options) + '=' + encode(value, options);
  }).filter(x => x.length > 0).join('&');
};

exports.parseUrl = (input, options) => {
  return {
    url: removeHash(input).split('?')[0] || '',
    query: parse(extract(input), options)
  };
};

},{"decode-uri-component":1,"split-on-first":4,"strict-uri-encode":5}],4:[function(require,module,exports){
'use strict';

module.exports = (string, separator) => {
  if (!(typeof string === 'string' && typeof separator === 'string')) {
    throw new TypeError('Expected the arguments to be of type `string`');
  }

  if (separator === '') {
    return [string];
  }

  const separatorIndex = string.indexOf(separator);

  if (separatorIndex === -1) {
    return [string];
  }

  return [string.slice(0, separatorIndex), string.slice(separatorIndex + separator.length)];
};

},{}],5:[function(require,module,exports){
'use strict';

module.exports = str => encodeURIComponent(str).replace(/[!'()*]/g, x => `%${x.charCodeAt(0).toString(16).toUpperCase()}`);

},{}],6:[function(require,module,exports){
"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.DEFAULT_SUBREDDITS=void 0;const DEFAULT_SUBREDDITS=["/r/askscience","/r/explainlikeimfive","/r/todayilearned"];exports.DEFAULT_SUBREDDITS=DEFAULT_SUBREDDITS;

},{}],7:[function(require,module,exports){
"use strict";var _preact=require("preact"),_queryString=require("query-string"),_constants=require("./constants.js");const errored=(0,_queryString.parse)(location.search).subreddit;chrome.storage.sync.get("subreddits",a=>{const b=a.subreddits&&a.subreddits.length?a.subreddits:_constants.DEFAULT_SUBREDDITS;a.subreddits&&a.subreddits.length||chrome.storage.sync.set({subreddits:b}),(0,_preact.render)((0,_preact.h)(RedditTriviaOptions,{subreddits:b}),document.getElementById("app"))});class RedditTriviaOptions extends _preact.Component{constructor({subreddits:a}){super(),this.setState({deletedSubreddits:[],inputValue:"",messages:[],subreddits:a})}updateInputValue(a){this.setState({inputValue:a.target.value})}onSubmit(a){const b=this.state.inputValue.trim();return a.preventDefault(),/\/r\/.+/.test(b)?this.state.subreddits.includes(b)?void alert("Already added"):void(this.setState({inputValue:"",subreddits:this.state.subreddits.concat(b)}),chrome.storage.sync.set({subreddits:this.state.subreddits.filter(a=>!this.state.deletedSubreddits.includes(a))}),setTimeout(()=>this.textInput.focus())):void alert("Must start with /r/")}onDelete(a){this.setState({deletedSubreddits:this.state.deletedSubreddits.concat(a)}),chrome.storage.sync.set({subreddits:this.state.subreddits.filter(a=>!this.state.deletedSubreddits.includes(a))})}onUndo(a){this.setState({deletedSubreddits:this.state.deletedSubreddits.filter(b=>b!==a)}),chrome.storage.sync.set({subreddits:this.state.subreddits.filter(a=>!this.state.deletedSubreddits.includes(a))})}render(){const a=this.state.subreddits.map(a=>{const b=this.state.deletedSubreddits.includes(a)?(0,_preact.h)("a",{class:"undo",onClick:this.onUndo.bind(this,a)},"undo"):(0,_preact.h)("a",{class:"delete",onClick:this.onDelete.bind(this,a)},"x");return(0,_preact.h)("li",{className:a===errored?"errored":""},(0,_preact.h)("label",{className:this.state.deletedSubreddits.includes(a)?"deleted":""},(0,_preact.h)("a",{href:"https://www.reddit.com"+a},a)),b)});return(0,_preact.h)("div",{class:"list"},(0,_preact.h)("ul",null,a),(0,_preact.h)("form",{onSubmit:this.onSubmit.bind(this)},(0,_preact.h)("input",{ref:a=>this.textInput=a,autofocus:!0,spellCheck:"false",type:"text",placeholder:"/r/new_subreddit",value:this.state.inputValue,onChange:this.updateInputValue.bind(this)}),(0,_preact.h)("button",{type:"submit",class:"add"},"ADD")))}}

},{"./constants.js":6,"preact":2,"query-string":3}]},{},[7]);
